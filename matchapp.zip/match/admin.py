from django.contrib import admin
from .models import Recruit,Profile,Skill,Language

admin.site.register(Recruit)
admin.site.register(Profile)
admin.site.register(Skill)
admin.site.register(Language)
